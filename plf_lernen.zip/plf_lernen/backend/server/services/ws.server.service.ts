import { Client, ClientMessage, ClientMessageType, IMessage } from "../models/types";
import WebSocket from "ws";

export let messages: IMessage[] = [];
export const clients = new Map<string, Client>();

export const addMessage = (message: IMessage) => {

    if (!message) {
        console.log("Message Fehler");
        return;
    }

    messages = [...messages, message];
    console.log(JSON.stringify(messages));
    sendAllMessages();
};

export const registerWs = (ws: WebSocket, name: string) => {

    if (!ws || !name) {
        console.log("Fehler beim register!");
        return;
    }

    clients.set(name, { id: name, ws, timeout: null });

    ws.send(JSON.stringify(messages));

    console.log(name + " erfolgreich registriert!");
};

export const sendWsMsgToAll = (msg: string) => {

    console.log("Sebi");

    for (let client of clients.values()) {
        console.log(msg);
        client.ws.send(msg);
    }

    console.log("Nachricht an alle User gesendet!");
};

export const sendAllMessages = () => {

    sendWsMsgToAll(JSON.stringify(messages));

    console.log("Alle Nachrichten an alle User gesendet!");
};


export const handleMessage = (msg: ClientMessage) => {

    switch (msg.type) {
        case ClientMessageType.RESET: {
            messages = [];
            sendAllMessages();
            console.log("Messages Reset!");
            break;
        }
    }
};
