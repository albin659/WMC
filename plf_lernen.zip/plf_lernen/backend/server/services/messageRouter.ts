import { Router } from "express";
import { IMessage } from "../models/types";
import { addMessage, clients } from "./ws.server.service";

const router = Router();

router.post("/message", (req, res) => {

    let msg: IMessage = req.body;

    if (!msg) {
        console.log("keine Message im body");
        res.status(400).json("kein body");
        return;
    }

    addMessage(msg);

    console.log("Message gesendet");

    res.status(201).json("erfolgreich");
});

router.post("/startTimer", (req, res) => {

    let msg: IMessage = req.body;

    if (!msg) {
        console.log("keine Message im body");
        res.status(400).json("kein body");
        return;
    }

    const url = new URL(req.url, "http://localhost:4000/");

    const name = url.searchParams.get("client_name");

    if (!name) {
        console.log("kein Name im body");
        res.status(400).json("kein body");
        return;
    }

    let client = clients.get(name);

    if (!client) {
        console.log("Nicht connected");
        res.status(400).json("Nicht connected");
        return;
    }

    if (client.timeout != null) {
        console.log("Intervall läuft schon");
        res.status(400).json("Intervall läuft schon");
        return;
    }

    const timeout = setInterval(() => {
        addMessage(msg);
    }, 10000);

    client.timeout = timeout;

    res.status(201).json("Timer erfolgreich gestartet");
});

router.post("/stopTimer", (req, res) => {

    const url = new URL(req.url, "http://localhost:4000/");

    const name = url.searchParams.get("client_name");

    if (!name) {
        console.log("kein Name im body");
        res.status(400).json("kein body");
        return;
    }

    let client = clients.get(name);

    if (!client) {
        console.log("Nicht connected");
        res.status(400).json("Nicht connected");
        return;
    }

    if (client.timeout == null) {
        console.log("Intervall läuft nicht");
        res.status(400).json("Intervall läuft nicht");
        return;
    }

    clearInterval(client.timeout);

    client.timeout = null;

    res.status(201).json("Timer erfolgreich geendet");
});

export default router;
