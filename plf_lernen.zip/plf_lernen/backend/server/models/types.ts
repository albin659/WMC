import WebSocket from "ws";

export type IMessage = {
    id: string,
    timestamp: Date,
    contend: string,
    userId: string
}

export type Client = {
    id: string,
    ws: WebSocket,
    timeout: NodeJS.Timeout | null
}

export enum ClientMessageType {
    RESET = "RESET"
}

export type ClientMessage = {
    type: ClientMessageType
}
