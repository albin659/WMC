import express from "express";
import cors from "cors";
import * as http from "node:http";
import { WebSocket, WebSocketServer } from "ws";
import { addMessage, clients, handleMessage, messages, registerWs } from "./services/ws.server.service";
import { ClientMessage, ClientMessageType, IMessage } from "./models/types";
import router from "./services/messageRouter";

const base = "http://localhost:4000/";

// muss man immer gleich machen ("ws") nicht vergessen

const app = express();
app.use(express.json());
app.use(cors());

const server = http.createServer(app);
const wsServer = new WebSocketServer({ server, path: "/ws" });

wsServer.on("connection", (ws: WebSocket, request: Request) => {

    // name aus path holen

    let urlString = request.url;
    if (urlString == undefined || !urlString) {
        console.log("keine url");
    }

    let url = new URL(request.url, base);
    let name = url.searchParams.get("client_name");
    if (!name) {
        console.log("No client name!");
        return;
    }

    registerWs(ws, name);

    ws.on("open", () => {
        console.log("Websocket geöffnet!");
    });

    // hier entweder das switch für message typ direkt oder in handleMessage ausgelagert
    ws.on("message", (raw) => {

        const msg: ClientMessage = JSON.parse(raw as unknown as string);

        if (!msg) {
            console.log("keine Message!");
            return;
        }

        handleMessage(msg);
    });

    ws.on("close", () => {
        // ka diggi
    });
});

// Routen eingebunden
app.use("/api", router);


// immer gleich
server.listen(4000, () => {
    console.log("Server läuft auf Port 4000");
});
