export type IMessage = {
    id: string,
    timestamp: Date,
    contend: string,
    userId: string
}

export enum ClientMessageType {
    RESET = "RESET"
}

export type ClientMessage = {
    type: ClientMessageType
}
