import { ClientMessage, ClientMessageType, IMessage } from "./models/types";
import { create } from "zustand/react";
import axios from "axios";

const base = "http://localhost:4000/";

type AppState = {
    id: string | null,
    messages: IMessage[],
    logs: string[],
    ws: WebSocket | null

    connect: (name: string) => void;
    sendMessage: (contend: string) => void;
    addLog: (log: string) => void;
    resetMessages: () => void;
    startTimer: (contend: string) => void;
    endTimer: () => void;
};

const useEpstein = create<AppState>((set, get) => ({

    id: null,
    messages: [],
    logs: [],
    ws: null,

    connect: (name: string) => {

        if (!name) {
            get().addLog("Keine name da");
            return;
        }

        const ws = new WebSocket(base + "ws?client_name=" + name);

        ws.onopen = () => {
            get().addLog("Opened!");
        };

        ws.onmessage = (raw) => {

            const messages: IMessage[] = JSON.parse(raw.data.toString());

            console.log(raw);

            set((_state) => ({
                messages: messages
            }));

            get().addLog("Server Msg: alle Messages");
        };

        set((_state) => ({
            id: name,
            ws: ws
        }));
    },

    sendMessage: (contend: string) => {

        const id = get().id;

        if (!id) {
            get().addLog("Nicht connected");
            return;
        }

        const msg: IMessage = { id: crypto.randomUUID(), timestamp: new Date(), contend: contend, userId: id };

        axios.post(base + "api/message", msg)
            .then((m) => get().addLog(m.data))
            .catch((e) => get().addLog(e.response.data || e.message));

        get().addLog("createdMsg = " + JSON.stringify(msg));
    },

    addLog: (log: string) => {

        set((_state) => ({
            logs: [..._state.logs, log]
        }));
    },

    resetMessages: () => {

        const msg: ClientMessage = { type: ClientMessageType.RESET };

        const ws = get().ws;

        if (!ws) {
            get().addLog("Fehler: nicht connected!");
            return;
        }

        ws.send(JSON.stringify(msg));

        get().addLog("Nachrichten reset!");
    },

    startTimer: (contend: string) => {

        const id = get().id;

        if (!id) {
            get().addLog("Nicht connected");
            return;
        }

        const msg: IMessage = { id: crypto.randomUUID(), timestamp: new Date(), contend: contend, userId: id };

        axios.post(base + "api/startTimer?client_name=" + id, msg)
            .then((m) => get().addLog(m.data))
            .catch((e) => get().addLog(e.response.data || e.message));
    },

    endTimer: () => {

        const id = get().id;

        if (!id) {
            get().addLog("Nicht connected");
            return;
        }

        axios.post(base + "api/stopTimer?client_name=" + id)
            .then((m) => get().addLog(m.data))
            .catch((e) => get().addLog(e.response.data || e.message));
    }
}));

export default useEpstein;
