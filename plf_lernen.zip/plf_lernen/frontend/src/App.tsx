import './App.css'
import Header from "./components/Header";
import MessageList from "./components/MessageList";

function App() {

    return (
        <>
            <Header />
            <MessageList />
        </>
    );
}

export default App;
