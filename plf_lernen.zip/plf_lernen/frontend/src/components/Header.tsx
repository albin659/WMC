import React, { useState } from 'react';
import { Button, TextField, Typography } from "@mui/material";
import useEpstein from "../zustand";

const Header = () => {

    const zustand = useEpstein();
    const [name, setName] = useState("");
    const [content, setContent] = useState("");
    //const {sendMessage, startTimer, stopTimer} = useMessage();

    return (
        <div>
            <Typography variant={"h2"}>Chat Message Log {zustand.id ? "open" : "not open"}</Typography>
            <Button onClick={() => zustand.connect(name)}>Connect</Button>
            <TextField onChange={(e) => setName(e.target.value)} value={name} />
            <TextField onChange={(e) => setContent(e.target.value)} value={content} />
            <Button onClick={() => zustand.sendMessage(content)}>Add Content</Button>
            <Button onClick={() => zustand.resetMessages()}>Reset</Button>
            <Button onClick={() => zustand.startTimer(content)}>Start Timer</Button>
            <Button onClick={() => zustand.endTimer()}>End Timer</Button>
        </div>
    );
};

export default Header;
