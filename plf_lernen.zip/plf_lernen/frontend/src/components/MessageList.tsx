import React from 'react';
import useEpstein from "../zustand";
import { Card, CardContent, CardHeader } from "@mui/material";

const MessageList = () => {

    const zustand = useEpstein();

    return (
        <div>
            {zustand.messages.map((e, i) => (
                <Card key={i} style={{ border: "5px solid black" }}>
                    <CardHeader title={e.userId + " ID: " + e.id + " | " + "Created: " + e.timestamp} />
                    <CardContent>
                        {e.contend}
                    </CardContent>
                </Card>
            ))}

            {zustand.logs.map((e, i) => (
                <Card key={i}>
                    {i + ": " + e.toString()}
                </Card>
            ))}
        </div>
    );
};

export default MessageList;
