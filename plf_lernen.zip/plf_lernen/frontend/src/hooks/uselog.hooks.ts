import { useState } from "react";

// unnötig

const useLog = () => {

    const [logs, setLogs] = useState<string[]>([]);

    const addLog = (log: string) => {
        setLogs(prev => [...prev, log]);
    };

    return { logs, addLog };
};

export default useLog;
