import axios from "axios";
import { IMessage } from "../models/types";
import useEpstein from "../zustand";

const base = "http://localhost:4000/";

// unnötig


const useMessage = () => {

    const state = useEpstein();

    const sendMessage = (contend: string) => {

        const id = state.id;

        if (!id) {
            state.addLog("Nicht connected");
            return;
        }

        const msg: IMessage = { id: crypto.randomUUID(), timestamp: new Date(), contend: contend, userId: id };

        axios.post(base + "api/message", msg)
            .then((m) => state.addLog(m.data))
            .catch((e) => state.addLog(e.response.data || e.message));

        state.addLog("createdMsg = " + JSON.stringify(msg));
    };

    const startTimer = (msg: IMessage, id: string) => {
        axios.post(base + "api/startTimer?client_name=" + id, msg);
    };

    const stopTimer = (id: string) => {
        axios.post(base + "api/stopTimer?client_name=" + id);
    };

    return { sendMessage, startTimer, stopTimer };
};

export default useMessage;
