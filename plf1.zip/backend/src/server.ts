import express, {json} from "express";
import cors from "cors";
import {createServer} from "node:http";
import {WebSocketServer, WebSocket} from "ws";
import {randomInt, randomUUID} from "node:crypto";
import {clearInterval, setInterval} from "node:timers";

const APPLICATION_PORT = 3000;
const APPLICATION_BASE_URL = `http://localhost:${APPLICATION_PORT}`;

const app = express();

app.use(cors());
app.use(json());

const server = createServer(app);
const wss = new WebSocketServer({server: server, path: "/ws"});

const clients = new Map<string, Client>();

const getAllMessages = (): ClientMessage[] => {
    return Array.from(clients.values())
        .flatMap(c =>
            c.messages.map(m => ({name: c.name, clientId: c._id, ...m}))
        );
}

const sendMessage = (c: Client, m: Message) => {
    if (!c.websocket) {
        console.log(`offline client '${c.name} cannot send messages`);
        return;
    }

    const message: WsServerMessage = {
        message: {name: c.name, clientId: c._id, ...m},
    };
    c.websocket.send(JSON.stringify(message));
}

type WsServerMessage = {
    message: ClientMessage;
}

type ClientMessage = ClientIdentifier & Message & {
    clientId: string,
};

type Message = {
    message: string,
    timestamp: number,
};

type Client = {
    _id: string,
    messages: Message[];
    websocket: WebSocket | null;
    interval: NodeJS.Timeout | null;
} & ClientIdentifier;

type ClientIdentifier = {
    name: string;
};

enum WsClientMessageType {
    SendMessage = "SEND_MESSAGE",
    Boop = "BOOP"
}

type PlainMessage = {
    message: string
}

type WsSendMessageData = PlainMessage;

type WsBoopData = {};

type WsClientMessage = {
    type: WsClientMessageType,
    data: WsSendMessageData | WsBoopData,
};

type ClientTimerMessage = PlainMessage & {
    timeout: number
};

wss.on("connection", (websocket, request) => {
    if (!request.url) {
        console.log("recieved malformed request: request URL must be present.");
        return;
    }

    const url = new URL(request.url, APPLICATION_BASE_URL);
    const clientName = url.searchParams.get("name");

    if (!clientName) {
        console.log("recieved malformed request: queryParam 'name' must be present in the request URL");
        return;
    }

    if (clients.has(clientName)) {
        console.log(`client '${clientName}' already registered`);
        return;
    }

    const client: Client = {
        _id: randomUUID(),
        name: clientName,
        messages: [],
        websocket: websocket,
        interval: null,
    };
    clients.set(clientName, client);
    console.log(`Successfully registered client ${clientName}`);

    websocket.on("message", (rawData) => {
        const message: WsClientMessage = JSON.parse(rawData as unknown as string);

        switch (message.type) {
            case WsClientMessageType.SendMessage: {
                const data = message.data as WsSendMessageData;

                const clientMessage = {message: data.message, timestamp: Date.now()};
                client.messages.push(clientMessage);
                sendMessage(client, clientMessage)

                break;
            }
            case WsClientMessageType.Boop: {
                const clientMessage = {message: "BOOP!", timestamp: Date.now()};
                client.messages.push(clientMessage);
                sendMessage(client, clientMessage);

                break;
            }
        }
    })
});

app.get("/messages", (req, res) => {
   res.status(200).send(getAllMessages());
})

app.post("/client/:name/start", (req, res) => {
    console.log("HIFAFSFA")
    const name = req.params.name;

    const client = clients.get(name);
    if (!client) {
        console.log(`no client with name '${name}' found.`);
        res.status(404).send(`no client with name '${name}' found.`);
        return;
    }

    if (client.interval) {
        console.log(`interval already started for client '${client.name}'.`);
        res.status(400).send(`interval already started for client '${client.name}'.`);
        return;
    }

    const body: ClientTimerMessage = req.body;

    console.log(`setting interval for ${client.name} every ${body.timeout}s...`)
    const timeout = setInterval(() => {
            const message: Message = {message: body.message, timestamp: Date.now()};
            client.messages.push(message);

            sendMessage(client, message);
        },
        body.timeout
    );

    client.interval = timeout;

    res.status(200).send(`interval for client ${client.name} started [${body.timeout}s].`);
});

app.post("/client/:name/stop", (req, res) => {
    const name = req.params.name;

    const client = clients.get(name);
    if (!client) {
        console.log(`no client with name '${name}' found.`);
        res.status(404).send(`no client with name '${name}' found.`);
        return;
    }

    if (!client.interval) {
        console.log(`no interval started for client '${client.name}'.`);
        res.status(400).send(`no interval started for client '${client.name}'.`);
        return;
    }

    clearInterval(client.interval);
    client.interval = null;

    res.status(200).send(`interval for client ${client.name} stopped.`);
})


server.listen(APPLICATION_PORT,  () => {
    console.log(`server listening on port ${APPLICATION_PORT}`);
});