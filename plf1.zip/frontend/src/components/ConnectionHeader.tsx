import {Button, Container, TextField, Typography} from "@mui/material";
import {useState} from "react";
import useAppStore from "../zustand";

const ConnectionHeader = () => {
   const store = useAppStore();
   const [name, setName] = useState<string>("");


    return (
        <Container>
            <TextField
                name={"username"}
                placeholder={"John Doe"}
                onChange={(e) => setName(e.target.value)}
            />

            <Button
                onClick={() => {store.connect({name: name})}}
            >
                Connect
            </Button>
        </Container>
    );
};

export default ConnectionHeader;