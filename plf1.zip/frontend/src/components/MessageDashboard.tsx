import useAppStore from "../zustand";
import {Button, Card, CardContent, CardHeader, Container, TextField, Typography} from "@mui/material";
import {useState} from "react";
import {Block} from "@mui/icons-material";

const MessageDashboard = () => {
    const store = useAppStore();

    const [message, setMessage] = useState<string>("");
    const [hideLogs, setHideLogs] = useState<boolean>(true);




    return (
        <Container>
            {/* Message Control*/}
            <Container>
                <TextField
                    name={"message"}
                    placeholder={"Hello World"}
                    onChange={(e) => setMessage(e.target.value)}
                />

                <Button
                    onClick={() => store.sendMessage({message: message})}
                >
                    Send
                </Button>
                <Button
                    onClick={() => store.boop()}
                >
                    Anstoßen
                </Button>

                <Container>
                    <Button
                        onClick={() => store.start({message: message})}
                    >
                        Send once per second
                    </Button>

                    <Button
                        onClick={store.stop}
                    >
                        Stop sending
                    </Button>
                </Container>
            </Container>

            {/*  Message Overview */}
            <Container>
                <Typography >Messages</Typography>
                {store.messages.map((v) => {
                    return <Card key={`${v.clientId}-${v.timestamp}`}>
                        <CardHeader title={`Author '${v.name} (${v.clientId})' @ ${new Date(v.timestamp).toLocaleString()}`} />
                        <CardContent>
                            {v.message}
                        </CardContent>
                    </Card>
                })}
            </Container>


            {/* Logs */}
            <Container hidden={hideLogs} >
                <Typography >Logs</Typography>
                {store.logs.map((v, k) => {
                    return <p key={k}>{k}: {v}</p>;
                })}
            </Container>
        </Container>
    );
};

export default MessageDashboard;