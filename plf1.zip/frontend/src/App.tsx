import React from "react"
import ConnectionHeader from "./components/ConnectionHeader";
import MessageDashboard from "./components/MessageDashboard";
import {Divider} from "@mui/material";

function App() {
    return (
        <>
            <ConnectionHeader></ConnectionHeader>
            <br/>
            <br/>
            <br/>
            <br/>
            <MessageDashboard></MessageDashboard>
        </>
    );
}

export default App;