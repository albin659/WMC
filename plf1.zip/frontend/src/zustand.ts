import {
    ClientIdentifier,
    ClientMessage, ClientTimerMessage,
    Message,
    PlainMessage,
    WsClientMessage,
    WsClientMessageType,
    WsServerMessage
} from "./types";
import {create} from "zustand/react";
import axios from "axios";

const APPLICATION_PORT = 3000;
const APPLICATION_BASE_URL = `http://localhost:${APPLICATION_PORT}`;

type AppStore = {
    client: ClientIdentifier | null;

    messages: ClientMessage[];
    sendMessage: (m: PlainMessage) => void;
    boop: () => void;

    logs: string[];
    addLog: (l: string) => void;

    start: (m: PlainMessage) => void;
    stop: () => void;

    websocket: WebSocket | null;
    connect: (client: ClientIdentifier) => void;
}

const useAppStore = create<AppStore>(
    (set, get) => ({
        client: null,

        messages: [],
        sendMessage: (m: PlainMessage) => {
            const ws = get().websocket;
            if (!ws) {
                get().addLog(`cannot send message: not connected.`);
                return;
            }

            const message: WsClientMessage = {
                type: WsClientMessageType.SendMessage,
                data: m
            };
            ws.send(JSON.stringify(message))
        },
        boop: () => {
            const ws = get().websocket;
            if (!ws) {
                get().addLog(`cannot send message: not connected.`);
                return;
            }

            const message: WsClientMessage = {
                type: WsClientMessageType.Boop,
                data: {}
            };
            ws.send(JSON.stringify(message))

        },


        start: (m: PlainMessage) => {
            const client = get().client;

            get().addLog("HIKFE");

            if(!client) {
                get().addLog(`cannot start: no client present.`);
                return;
            }

            const body: ClientTimerMessage = {
                timeout: 1_000,
                ...m
            };

            get().addLog("HIKFE2");
            axios.post(`${APPLICATION_BASE_URL}/client/${client.name}/start`, body)
                .then((res) => get().addLog(`server: ${res.statusText}`))
                .catch((reason) => get().addLog(`server: ${reason}`));

            get().addLog("HIKFE3");
        },
        stop: () => {
            const client = get().client;

            if(!client) {
                get().addLog(`cannot start: no client present.`);
                return;
            }

            axios.post(`${APPLICATION_BASE_URL}/client/${client.name}/stop`,)
                .then((res) => get().addLog(`server: ${res.statusText}`))
                .catch((reason) => get().addLog(`server: ${reason}`));
        },

        logs: [],
        addLog: (l: string) => {
            set((state) =>
                ({logs: [...state.logs, l]})
            );
        },

        websocket: null,
        connect: (client: ClientIdentifier) => {
            if (get().websocket) {
                get().addLog(`already connected.`);
                return;
            }

            const ws = new WebSocket(`${APPLICATION_BASE_URL}/ws?name=${client.name}`);
            get().addLog(`successfully connected as '${client.name}'.`);

            ws.onmessage = (me) => {
                const data: WsServerMessage = JSON.parse(me.data.toString());

                set((state) =>
                    ({messages: [...state.messages, data.message]})
                );

                get().addLog(`received message: ${data.message.message}.`);
            };

            ws.onclose = () => {
                get().addLog(`closing connection for '${get().client}'...`);
                set((_state) =>
                    ({
                        websocket: null,
                        client: null
                    })
                );
            }


            axios.get(`${APPLICATION_BASE_URL}/messages`,)
                .then((res) => {
                    get().addLog(`server: ${res.statusText}`);

                    const allMessages: ClientMessage[] = res.data;
                    set((state) =>
                        ({messages: [...state.messages, ...allMessages]})
                    );
                })
                .catch((reason) => get().addLog(`server: ${reason}`));

            set((_state) =>
                ({
                    websocket: ws,
                    client: client
                })
            );
        },
    })
);

export default useAppStore;