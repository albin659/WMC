export type WsServerMessage = {
    message: ClientMessage;
}

export type ClientMessage = ClientIdentifier & Message & {
    clientId: string,
};

export type Message = {
    message: string,
    timestamp: number,
};

export type ClientIdentifier = {
    name: string;
};

export enum WsClientMessageType {
    SendMessage = "SEND_MESSAGE",
    Boop = "BOOP"
}

export type PlainMessage = {
    message: string
}

export type WsSendMessageData = PlainMessage;

export type WsBoopData = {};

export type WsClientMessage = {
    type: WsClientMessageType,
    data: WsSendMessageData | WsBoopData,
};

export type ClientTimerMessage = PlainMessage & {
    timeout: number
};